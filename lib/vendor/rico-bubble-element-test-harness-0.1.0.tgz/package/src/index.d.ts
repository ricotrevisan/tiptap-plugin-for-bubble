export type Properties = Record<string, any>;
export interface Instance {
  canvas: any;
  data: Record<string, any>;
  publishState(name: string, value: any): void;
  triggerEvent(name: string): void;
  [method: string]: any;
}
export type Context = Record<string, any>;
export interface Sources {
  initialize: string;
  update?: string;
  reset?: string;
  actions?: Record<string, string>;
}
export interface Callbacks {
  initialize(instance: Instance, context: Context): any;
  update?(instance: Instance, properties: Properties, context: Context): any;
  reset?(instance: Instance, context: Context): any;
  actions?: Record<string, (instance: Instance, properties: Properties, context: Context) => any>;
}
export interface EventSnapshot { type: "event"; name: string; states: Record<string, any> }
export interface StatePublication { type: "state"; name: string; value: any }
export function compileCallbacks(bodies: Sources): Callbacks;
export function loadCallbacks(urls: Sources, fetchSource?: typeof fetch): Promise<Callbacks>;
export function createHarness(options: {
  callbacks: Callbacks;
  canvas: any;
  context?: Context;
  methods?: Record<string, (...args: any[]) => any>;
  snapshot?: (value: any) => any;
}): {
  instance: Instance;
  states: Record<string, any>;
  events: EventSnapshot[];
  history: (EventSnapshot | StatePublication)[];
  initialize(): any;
  update(properties: Properties): any;
  reset(): any;
  action(name: string, properties: Properties): any;
};
export function bubbleList<T>(values: T[]): { length(): number; get(start: number, count: number): T[] };
export function bubbleThing<T extends Record<string, any>>(fields: T): { get<K extends keyof T>(field: K): T[K] };
