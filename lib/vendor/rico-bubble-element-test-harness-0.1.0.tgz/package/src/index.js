const signatures = {
  initialize: ["instance", "context"],
  update: ["instance", "properties", "context"],
  reset: ["instance", "context"],
  action: ["instance", "properties", "context"],
};

/** Compile trusted decoded Pled bodies in the current (browser) realm. */
export function compileCallbacks({ initialize, update, reset, actions = {} }) {
  const compile = (kind, body, name = kind) => {
    if (typeof body !== "string") throw new TypeError(`${name}: expected a decoded callback body`);
    try {
      return new Function(...signatures[kind], body);
    } catch (cause) {
      throw new SyntaxError(`Cannot compile ${name}: ${cause.message}`, { cause });
    }
  };
  return {
    initialize: compile("initialize", initialize),
    ...(update === undefined ? {} : { update: compile("update", update) }),
    ...(reset === undefined ? {} : { reset: compile("reset", reset) }),
    actions: Object.fromEntries(Object.entries(actions).map(([name, body]) => [name, compile("action", body, `action ${name}`)])),
  };
}

/** Fetch only explicitly named source URLs; reject HTTP failures before compilation. */
export async function loadCallbacks({ initialize, update, reset, actions = {} }, fetchSource = globalThis.fetch) {
  const read = async (url) => {
    const response = await fetchSource(url);
    if (!response.ok) throw new Error(`Callback fetch failed: ${url} (HTTP ${response.status})`);
    return response.text();
  };
  const entries = [["initialize", initialize], ...Object.entries({ update, reset }).filter(([, url]) => url !== undefined)];
  const bodies = Object.fromEntries(await Promise.all(entries.map(async ([key, url]) => [key, await read(url)])));
  const actionBodies = Object.fromEntries(await Promise.all(Object.entries(actions).map(async ([key, url]) => [key, await read(url)])));
  return compileCallbacks({ ...bodies, actions: actionBodies });
}

function explicit(object, label) {
  return new Proxy(object, {
    get(target, key, receiver) {
      if (Reflect.has(target, key) || typeof key === "symbol") return Reflect.get(target, key, receiver);
      throw new Error(`Unsupported ${label}.${key}; supply an explicit implementation in the fixture`);
    },
  });
}

/**
 * Canvas is passed through unchanged: use a DOM element, array, or real jQuery
 * according to the consuming adapter. No layout or Bubble methods are invented.
 */
export function createHarness({ callbacks, canvas, context = {}, methods = {}, snapshot = structuredClone }) {
  if (canvas == null) throw new TypeError("An explicit canvas is required");
  for (const key of ["canvas", "data", "publishState", "triggerEvent"]) {
    if (Object.hasOwn(methods, key)) throw new Error(`Cannot override instance.${key}`);
  }
  const states = Object.create(null);
  const history = [];
  const events = [];
  const instance = explicit({
    ...methods,
    canvas,
    data: {},
    publishState(name, value) {
      // Clone before recording so an unsupported value cannot partially publish.
      const captured = snapshot(value);
      states[name] = value;
      history.push({ type: "state", name, value: captured });
    },
    triggerEvent(name) {
      const entry = { type: "event", name, states: snapshot(states) };
      events.push(entry);
      history.push(entry);
    },
  }, "instance");
  const suppliedContext = explicit(context, "context");
  const invoke = (kind, properties) => {
    if (typeof callbacks[kind] !== "function") throw new Error(`No ${kind} callback supplied`);
    return kind === "update"
      ? callbacks[kind](instance, properties, suppliedContext)
      : callbacks[kind](instance, suppliedContext);
  };
  return {
    instance, states, events, history,
    initialize: () => invoke("initialize"),
    update: (properties) => invoke("update", properties),
    reset: () => invoke("reset"),
    action(name, properties) {
      if (!Object.hasOwn(callbacks.actions ?? {}, name)) throw new Error(`No action callback supplied: ${name}`);
      return callbacks.actions[name](instance, properties, suppliedContext);
    },
  };
}

/** Synchronous, zero-based slice as consumed by Pled adapters. No lazy loading. */
export function bubbleList(values) {
  if (!Array.isArray(values)) throw new TypeError("bubbleList requires an array");
  const items = values.slice();
  return explicit({
    length: () => items.length,
    get(start, count) {
      if (!Number.isSafeInteger(start) || start < 0 || !Number.isSafeInteger(count) || count < 0)
        throw new RangeError("Bubble list get requires non-negative integer start and count");
      return items.slice(start, start + count);
    },
  }, "Bubble list");
}

/** Explicit fields only; missing fields fail rather than fabricating empty data. */
export function bubbleThing(fields) {
  const values = { ...fields };
  return explicit({
    get(field) {
      if (!Object.hasOwn(values, field)) throw new Error(`Missing Bubble Thing field: ${field}`);
      return values[field];
    },
  }, "Bubble Thing");
}
