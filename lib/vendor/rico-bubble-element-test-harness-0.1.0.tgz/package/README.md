# Bubble element test harness

A small browser module for executing **trusted decoded Pled element callback bodies** against an explicit instance. It is not a Bubble emulator.

## Install a versioned local package

From this repository:

    npm ci
    npm run test:package
    npm pack --pack-destination /path/to/consumer/vendor

In the consumer, commit the tarball and lockfile:

    npm install --save-dev --save-exact ./vendor/rico-bubble-element-test-harness-0.1.0.tgz

CI then runs `npm ci` without this source checkout, an absolute dependency path, or a registry publication. Change the version before distributing changes; never overwrite an adopted version. The lockfile records archive integrity. Share that versioned archive or later publish to an authorized registry.

## Browser fixture

Load the consumer's **built runtime** first. Serve the installed module and actual decoded `src/` files through a local test server:

```js
import { loadCallbacks, createHarness } from
  '/node_modules/@rico/bubble-element-test-harness/src/index.js';
const callbacks = await loadCallbacks({
  initialize: '/src/elements/example/initialize.js',
  update: '/src/elements/example/update.js',
  reset: '/src/elements/example/reset.js',
  actions: { set: '/src/elements/example/actions/set.js' },
});
const h = createHarness({
  callbacks,
  canvas: [document.querySelector('#host')],
  context: { reportDebugger: message => { throw Error(message); } },
});
h.initialize();
h.update({ value: 'Alpha' }); // consumer owns every property
h.action('set', { value: 'Beta' });
h.reset();
```

`compileCallbacks` instead accepts source strings. Compilation uses `new Function` in the calling realm: initialize/reset receive `(instance, context)`; update/actions receive `(instance, properties, context)`. This requires trusted local code and CSP allowing Function construction; it does not evaluate Bubble expressions. HTTP/syntax errors fail explicitly. Missing optional callbacks fail on invocation. Empty supplied bodies are valid no-ops.

Each harness has independent persistent `instance.data`. Calls return callback results, including promises; consumers await application readiness. Reset calls the real body without clearing data/history or imposing scheduling.

`states` contains latest published values. `history` interleaves `{type:'state', name, value}` and `{type:'event', name, states}` records. `events` contains event-time snapshots. Recordings use `structuredClone`, so later plugin mutations cannot rewrite earlier recordings. Treat records as read-only. Non-cloneable values, including Thing proxies, fail explicitly: provide a fixture-specific `snapshot(value)` handling individual values and state maps if needed. No automatic lossy serialization occurs.

Canvas is required and passed through unchanged. Use a DOM node/array when that is what the adapter consumes; use real jQuery for `.css()`, `.parent()`, `.find()`, etc. No layout or jQuery is simulated. Extra instance methods belong in `methods`, context methods in `context`. Absent methods throw, including feature probes. Reserved instance members cannot be overridden. No successful fake uploads, autobinding or database access are supplied.

`bubbleList(array)` supports synchronous `length()` and zero-based `get(start, count)` slices only. `bubbleThing(fields)` supports `get(field)` for supplied fields only. Missing fields and unsupported operations throw. Explicit null/undefined fields remain explicit. These match Tiptap mention reads and Modern Dropdown list reads, without modeling lazy loading, privacy or database identity. See [typed example](examples/usage.ts).

## Evidence and verification

Modern Dropdown's `fixtures/bubble.html` and `tests/browser/bubble-lifecycle.spec.js` established real bodies/signatures, persistent data and snapshots. Its `fixtures/popover.html` and `tests/browser/popover.spec.js` demonstrate why layout, bundle loading and UI assertions stay in consumers. That checkout was read only.

Tiptap integration on `test/reusable-bubble-harness`, based on `91d1d43`, lives under `lib/tests/browser`. It uses real jQuery, explicit properties, the packed dev dependency, built runtime and actual adapter bodies.

Run `npm test`, `npm run typecheck`, and `npm run test:package`. No compilation step is required: runtime is browser ESM with declarations.

## Still requires real Bubble

Verify editor property/expression resolution, callback scheduling, workflows after events, uploads, autobinding persistence, repeating-group lifecycle, app CSS/layout, permissions, lazy Thing/list loading, collaboration and external services in real Bubble. Browser tests verify only the supplied environment and scenarios. This package does not modify, push, publish or access a Bubble app.
