import { loadCallbacks, createHarness, bubbleList, bubbleThing } from "@rico/bubble-element-test-harness";

// Serve actual decoded src files alongside the consumer's built runtime.
const callbacks = await loadCallbacks({
  initialize: "/src/elements/example/initialize.js",
  update: "/src/elements/example/update.js",
  reset: "/src/elements/example/reset.js",
  actions: { choose: "/src/elements/example/actions/choose.js" },
});
const root = document.createElement("div");
document.body.append(root);
const harness = createHarness({ callbacks, canvas: [root] });
harness.initialize();
harness.update({
  options: bubbleList([bubbleThing({ label: "Alpha", id: "a" })]),
});
harness.action("choose", { value: "a" });
harness.reset();
console.log(harness.history);
